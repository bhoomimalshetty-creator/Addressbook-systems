#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include "contact.h"

#define MAX 100 // Maximum contacts allowed in the address book

// ===== NAME VALIDATION =====
// Returns 1 if valid, 0 otherwise
int validate_name(char *name) 
{
    int len = strlen(name);
    if(len < 4)  // Check minimum length
    {
        printf(RED"Error : name must contain at least 4 characters\n"RESET);
        return 0;
    }
    for(int i = 0; name[i] != '\0'; i++) // Checks all characters are alphabets
    {
        if(!isalpha(name[i]) && name[i] != ' ')
        {
            printf(RED"Error : Name should contain only alphabets (A-Z, a-z) and spaces\n"RESET);
            return 0;
        }  
    }
    return 1;// Valid name
}
// ===== MOBILE VALIDATION =====
// Returns 1 if mobile number is valid, otherwise 0
int validate_mobile(char *mobile)
{
    if(strlen(mobile) != 10) // check length is exactly 10 digits
    {
        printf(RED"Error : Phone number must contain exactly 10 digits\n"RESET);
        return 0;
    }
    
    if(mobile[0] < '6' || mobile[0] > '9') //first digit should be between 6 to 9
    {
        printf(RED"Error : First digit must be between 6 and 9\n"RESET);
        return 0;
    }

    for(int i = 0; mobile[i]; i++) //check all digit
    {
        if(!isdigit(mobile[i]))
        {
            printf(RED"Error : Only digits are allowed in phone number\n"RESET);
            return 0;
        }
    }
    return 1; // Valid mobile
}
// ===== EMAIL VALIDATION =====
// Return 1 if email is valid, otherwise 0
int validate_email(char *email)
{
    int at_count = 0, dot_count = 0;
    for(int i = 0; email[i]; i++)// Count @ and . and check invalid symbols
    {
        if(isupper(email[i]))
        {
            printf(RED"Error: Email must not contain uppercase letters\n"RESET);
            return 0;
        }
        if(email[i] == '@')
        at_count++;
        else if(email[i] == '.')
        dot_count++;
        else if(!isalnum(email[i]))
        {
            printf(RED"Error : Invalid symbol in email\n"RESET);
            return 0;
        }
    }

    if(at_count != 1) // Must have exactly one '@
    {
        printf(RED"Error : email must contain exactly one '@'\n"RESET);
        return 0;
    }
    if(dot_count < 1) // Must have at least one dot
    {
        printf(RED"Error : Email must contain at least one '.'\n"RESET);
        return 0;
    }
    char *at = strchr(email, '@');
    char *dot = strrchr(email, '.');
    if(dot < at) // Dot must appear after @
    {
        printf(RED"Error : '.' must be after '@\n"RESET);
        return 0;
    }
    if(dot == at + 1) // At least one character between @ and .
    {
        printf(RED"Error : There must be characters between '@' and '.'\n"RESET);
        return 0;
    }
    // Check domain characters
    for(char *p = at + 1; *p; p++)
    {
        if(*p != '.' && !isalnum(*p))
        {
            printf(RED"Error : invalid character in domain\n"RESET);
            return 0;
        }
    }
    // Check domain extension
    char *ext = dot + 1;
    if(*ext == '\0')
    {
        printf(RED"Error : Domain extension missing\n"RESET);
        return 0;
    }
    for(char *p = ext; *p; p++)
    {
        if(!islower(*p))
        {
            printf(RED"Error : Domain extension must be lowercase alphabets only(no numbers or uppercase)\n"RESET);
            return 0;
        }
    }
    for(char *p = ext; *p; p++)
    {
        if(*p == '.')
        {
            printf(RED"Error : Extra domain extension not allowed\n"RESET);
            return 0;
        }
    }
    return 1;
}
// Duplicate check (mobile + email)
// Returns 1 if mobile or email already exists, otherwise 0
int is_duplicate(AddressBook *ab, char mobile[], char email[])
{
    for(int i = 0; i < ab->contact_count; i++)
    {
        if(mobile[0] != '\0' && 
            strcmp(mobile,ab->contact_details[i].Mobile_number) == 0)
        {
            printf(RED"Error: Mobile nuber already existd!\n"RESET);
            return 1;
        }
        if(email[0] != '\0' &&
            strcmp(email,ab->contact_details[i].Mail_ID) == 0)
        {
            printf(RED"Error: Email already exists!\n"RESET);
            return 1;

        }
        
    }
    return 0; // No duplicate
}
// ===== CREAT NEW CONTACT =====
// Adds a new contact with validation and duplicate checks
Status create_contact(AddressBook *ab)
{
    char option;
    do
    {
    if(ab->contact_count>=MAX) // check limit
    {
        printf("Address book full!\n");
        return Failure;
    }
    char name[50], mobile[15], email[50];
    // Input name untill valid
    while(1)
    {
        printf(BLUE"Enter Name: "RESET);
        fgets(name, sizeof(name), stdin);
        name[strcspn(name, "\n")] = '\0';

        if(validate_name(name)) // validate name
        break;
    
    }

    // Input mobile untill valid
    while(1)
    {
        printf(BLUE"Enter Mobile: "RESET);
        fgets(mobile, sizeof(mobile), stdin);
        mobile[strcspn(mobile, "\n")] = '\0';

        if(!validate_mobile(mobile))
        continue;
        if(is_duplicate(ab, mobile, ""))
        continue;
        break;
    }

    // Input email until valid and unique
    while(1)
    {
        printf(BLUE"Enter Email: "RESET);
        fgets(email, sizeof(email), stdin);
        email[strcspn(email, "\n")] = '\0';
        if(!validate_email(email))
        continue;
        if(is_duplicate(ab, "", email))
        continue;
        break;
    }
    //store contact
    strcpy(ab->contact_details[ab->contact_count].Name, name);
    strcpy(ab->contact_details[ab->contact_count].Mobile_number, mobile);
    strcpy(ab->contact_details[ab->contact_count].Mail_ID, email);
    ab->contact_count++; // store contact

    printf(GREEN"\nSUCCESS:Contact created successfully!\n"RESET);
    // Display all contacts in table format
        printf(WHITE"\n+------+----------------+--------------+--------------------------+\n"RESET);
        printf(YELLOW"| %-4s | %-14s | %-12s | %-24s |\n"RESET, "S.No", "Name", "Mobile", "Email");
        printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
        for(int i = 0; i < ab->contact_count; i++)
        {
            printf("| %-4d | %-14s | %-12s | %-24s |\n",
                   i + 1,
                   ab->contact_details[i].Name,
                   ab->contact_details[i].Mobile_number,
                   ab->contact_details[i].Mail_ID);
        }
        printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
        printf("\nContact List Updated Successfully\n");

        // Ask to add another contact
        printf("\nDo you want to add another contact? (y/n) : ");
        scanf(" %c", &option);
        getchar(); // clear newline
    } while(option == 'y' || option == 'Y');

    return Success;
}
// ===== SEARCH CONTACT MENU =====
// Allows search by name, mobile, or email
Status search_contacts(AddressBook *ab)
{

    int option;
    char choice;

    do
    {
        int found = 0;

        printf(CYAN"\n===== SEARCH CONTACT MENU =====\n"RESET);
        printf("1. Search by Name\n");
        printf("2. Search by Mobile\n");
        printf("3. Search by Email\n");
        printf("4. Exit\n");
        printf("Enter your option: ");
        scanf("%d", &option);
        getchar();  // clear newline from buffer

        if(option == 4)
        {
            printf("Exiting search menu...\n");
            return Success;
        }

        char input[50];

        // Input based on option
        if(option == 1)
        {
            printf("Enter name to search: ");
            fgets(input, sizeof(input), stdin);
        }
        else if(option == 2)
        {
            printf("Enter mobile number: ");
            fgets(input, sizeof(input), stdin);
        }
        else if(option == 3)
        {
            printf("Enter email: ");
            fgets(input, sizeof(input), stdin);
        }
        else
        {
            printf(RED"Invalid option!\n"RESET);
            continue;
        }

        // Remove trailing newline
        input[strcspn(input, "\n")] = '\0';

        int match_index[100];
        int match_count = 0;

        // Search logic
        for(int i = 0; i < ab->contact_count; i++)
        {
            if((option == 1 && strcasecmp(input, ab->contact_details[i].Name) == 0) ||
               (option == 2 && strcmp(input, ab->contact_details[i].Mobile_number) == 0) ||
               (option == 3 && strcasecmp(input, ab->contact_details[i].Mail_ID) == 0))
            {
                match_index[match_count++] = i;
            }
        }

        // No match found messages
        if(match_count == 0)
        {
            if(option == 1)
                printf("\nNo contact found with this name!\n");
            else if(option == 2)
                printf("\nNo contact found with this mobile number!\n");
            else if(option == 3)
                printf("\nNo contact found with this email!\n");
        }
        else
        {
            // Table header
            printf(WHITE"\n+------+----------------+--------------+--------------------------+\n"RESET);
            printf(YELLOW"| %-4s | %-14s | %-12s | %-24s |\n"RESET, "S.No", "Name", "Mobile", "Email");
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);

            // Table rows
            for(int i = 0; i < match_count; i++)
            {
                int idx = match_index[i];
                printf("| %-4d | %-14s | %-12s | %-24s |\n",
                       i + 1,
                       ab->contact_details[idx].Name,
                       ab->contact_details[idx].Mobile_number,
                       ab->contact_details[idx].Mail_ID);
            }

            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
        }

        // Completed message
        printf("\nSearched Completely\n");

        // Ask to search again
        printf("\nDo you want to search another contact? (y/n): ");
        scanf(" %c", &choice);
        getchar(); // clear newline
    } while(choice == 'y' || choice == 'Y');

    return Success;
}

// ===== EDIT CONTACT =====
// Allows editing contact by name, mobile, or email
Status edit_contact(AddressBook *ab)
{
    char continue_edit = 'y';

    while(continue_edit == 'y' || continue_edit == 'Y')
    {
        int option;
        char input[50];
        printf(CYAN"\n===== EDIT CONTACT MENU =====\n"RESET);
        printf("1. Edit by Name\n");
        printf("2. Edit by Mobile\n");
        printf("3. Edit by Email\n");
        printf("4. Exit\n");
        printf("Enter option: ");
        scanf("%d", &option);
        getchar(); // clear input buffer

        if(option == 4)
            return Success;

        if(option < 1 || option > 4)
        {
            printf("Invalid option!\n");
            continue;
        }

        // Ask input based on search option
        if(option == 1)
            printf("Enter name to search: ");
        else if(option == 2)
            printf("Enter mobile number to search: ");
        else
            printf("Enter email to search: ");

        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';

        int match_index[100];
        int match_count = 0;

        // Search for matching contacts
        for(int i = 0; i < ab->contact_count; i++)
        {
            if((option == 1 && strcasecmp(input, ab->contact_details[i].Name) == 0) ||
               (option == 2 && strcmp(input, ab->contact_details[i].Mobile_number) == 0) ||
               (option == 3 && strcasecmp(input, ab->contact_details[i].Mail_ID) == 0))
            {
                match_index[match_count++] = i;
            }
        }

        if(match_count == 0)
        {
            printf("No contact found!\n");
        }
        else
        {
            // Display matching contacts in table
            printf("\nMatching Contacts:\n");
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
            printf(YELLOW"| %-4s | %-14s | %-12s | %-24s |\n"RESET, "S.No", "Name", "Mobile", "Email");
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
            for(int i = 0; i < match_count; i++)
            {
                int idx = match_index[i];
                printf(WHITE"| %-4d | %-14s | %-12s | %-24s |\n"RESET,
                       i + 1,
                       ab->contact_details[idx].Name,
                       ab->contact_details[idx].Mobile_number,
                       ab->contact_details[idx].Mail_ID);
            }
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);

            int choice = 1;
            if(match_count > 1)
            {
                printf("Select contact to edit (1-%d): ", match_count);
                scanf("%d", &choice);
                getchar();
                if(choice < 1 || choice > match_count)
                {
                    printf("Invalid selection!\n");
                    continue;
                }
            }

            int i = match_index[choice - 1];

            char confirm;
            printf("Do you want to edit this contact? (y/n): ");
            scanf(" %c", &confirm);
            getchar();

            if(confirm == 'y' || confirm == 'Y')
            {
                // Edit logic
                if(option == 1) // Edit Name
                {
                    char new_name[50];
                    while(1)
                    {
                        printf("Enter new name: ");
                        fgets(new_name, sizeof(new_name), stdin);
                        new_name[strcspn(new_name, "\n")] = '\0';
                        if(validate_name(new_name))
                            break;
                    }
                    strcpy(ab->contact_details[i].Name, new_name);
                }
                else if(option == 2) // Edit Mobile
                {
                    char new_mobile[15];
                    while(1)
                    {
                        int duplicate = 0;
                        printf("Enter new mobile: ");
                        fgets(new_mobile, sizeof(new_mobile), stdin);
                        new_mobile[strcspn(new_mobile, "\n")] = '\0';

                        if(!validate_mobile(new_mobile))
                            continue;

                        for(int j = 0; j < ab->contact_count; j++)
                        {
                            if(j != i && strcmp(new_mobile, ab->contact_details[j].Mobile_number) == 0)
                            {
                                printf(RED"Error: Mobile number already exists!\n"RESET);
                                duplicate = 1;
                                break;
                            }
                        }
                        if(!duplicate) break;
                    }
                    strcpy(ab->contact_details[i].Mobile_number, new_mobile);
                }
                else if(option == 3) // Edit Email
                {
                    char new_email[50];
                    while(1)
                    {
                        int duplicate = 0;
                        printf("Enter new email: ");
                        fgets(new_email, sizeof(new_email), stdin);
                        new_email[strcspn(new_email, "\n")] = '\0';

                        if(!validate_email(new_email))
                            continue;

                        for(int j = 0; j < ab->contact_count; j++)
                        {
                            if(j != i && strcmp(new_email, ab->contact_details[j].Mail_ID) == 0)
                            {
                                printf(RED"Error: Email already exists!\n"RESET);
                                duplicate = 1;
                                break;
                            }
                        }
                        if(!duplicate) break;
                    }
                    strcpy(ab->contact_details[i].Mail_ID, new_email);
                }

                printf(GREEN"\nContact updated successfully!\n"RESET);

                // Show updated contact
                printf("\nUpdated Contact:\n");
                printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
                printf(YELLOW"| %-4s | %-14s | %-12s | %-24s |\n"RESET, "S.No", "Name", "Mobile", "Email");
                printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
                printf("| %-4d | %-14s | %-12s | %-24s |\n",
                       choice,
                       ab->contact_details[i].Name,
                       ab->contact_details[i].Mobile_number,
                       ab->contact_details[i].Mail_ID);
                printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
            }
            else
            {
                printf("Edit cancelled.\n");
            }
        }

        printf("\nDo you want to edit another contact? (y/n): ");
        scanf(" %c", &continue_edit);
        getchar();
    }

    return Success;
}
// ===== DELETE CONTACT =====
// Allows deletion of a contact with confirmaton
Status delete_contact(AddressBook *ab)
{
    char continue_delete = 'y';

    while(continue_delete == 'y' || continue_delete == 'Y')
    {
        int option;
        char input[50];

        printf(CYAN"\n===== DELETE CONTACT MENU =====\n"RESET);
        printf("1. Delete by Name\n");
        printf("2. Delete by Mobile\n");
        printf("3. Delete by Email\n");
        printf("4. Exit\n");
        printf("Enter option: ");
        scanf("%d", &option);
        getchar(); // clear newline from buffer

        if(option < 1 || option > 4)
        {
            printf("Invalid option!\n");
            continue;
        }

        if(option == 4)
            return Success;

        // Ask for input based on option
        if(option == 1)
            printf("Enter name to delete: ");
        else if(option == 2)
            printf("Enter mobile number to delete: ");
        else
            printf("Enter email ID to delete: ");
        scanf("%s", input);

        int match_index[100];
        int match_count = 0;

        // Find all matching contacts
        for(int i = 0; i < ab->contact_count; i++)
        {
            if((option == 1 && strcasecmp(input, ab->contact_details[i].Name) == 0) ||
               (option == 2 && strcmp(input, ab->contact_details[i].Mobile_number) == 0) ||
               (option == 3 && strcasecmp(input, ab->contact_details[i].Mail_ID) == 0))
            {
                match_index[match_count++] = i;
            }
        }

        if(match_count == 0)
        {
            printf("No matching contact found!\n");
            continue;
        }

        // If multiple matches, show table and let user select
        int choice = 1;
        if(match_count > 1)
        {
            printf("\nMultiple contacts found:\n");
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
            printf(YELLOW"| S.No | Name           | Mobile       | Email                    |\n"RESET);
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
            for(int i = 0; i < match_count; i++)
            {
                int idx = match_index[i];
                printf("| %-4d | %-14s | %-12s | %-24s |\n",
                       i+1,
                       ab->contact_details[idx].Name,
                       ab->contact_details[idx].Mobile_number,
                       ab->contact_details[idx].Mail_ID);
            }
            printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
            printf("Select contact to delete (1-%d): ", match_count);
            scanf("%d", &choice);
            getchar();
            if(choice < 1 || choice > match_count)
            {
                printf("Invalid selection!\n");
                continue;
            }
        }

        int del_index = match_index[choice - 1];

        // Confirm deletion
        printf("\nContact Found:\n");
        printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
        printf(YELLOW"| S.No | Name           | Mobile       | Email                    |\n"RESET);
        printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
        printf("| 1    | %-14s | %-12s | %-24s |\n",
               ab->contact_details[del_index].Name,
               ab->contact_details[del_index].Mobile_number,
               ab->contact_details[del_index].Mail_ID);
        printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);

        char confirm;
        printf("Do you want to delete this contact? (y/n): ");
        scanf(" %c", &confirm);
        getchar();

        if(confirm == 'y' || confirm == 'Y')
        {
            // Shift all subsequent contacts up
            for(int j = del_index; j < ab->contact_count - 1; j++)
            {
                ab->contact_details[j] = ab->contact_details[j + 1];
            }
            ab->contact_count--;
            printf(GREEN"Contact deleted successfully!\n"RESET);
            save_contacts(ab);
        }
        else
        {
            printf("Deletion cancelled.\n");
        }

        printf("\nDo you want to delete another contact? (y/n): ");
        scanf(" %c", &continue_delete);
        getchar();
    }

    return Success;

}
// ===== LIST ALL CONTACTS =====
// Display all saved contacts in formatted output
void list_contacts(AddressBook *ab)
{
    if(ab->contact_count == 0)
    {
        printf("\nNo contacts found.\n");
        return;
    }
    printf(CYAN"\n===== All Contacts =====\n"RESET);
    printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
    printf(YELLOW"| S.No | Name           | Mobile       | Email                    |\n");
    printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
    for(int i = 0; i < ab->contact_count; i++) 
    {
        printf("| %-4d | %-14s | %-12s | %-24s |\n",i+1,
               ab->contact_details[i].Name,
               ab->contact_details[i].Mobile_number,
               ab->contact_details[i].Mail_ID);
    }
    printf(WHITE"+------+----------------+--------------+--------------------------+\n"RESET);
}
// ===== SAVE CONTACT TO FILE ======
// Writes all contacts to "contacts.txt"
Status save_contacts(AddressBook *ab)
{
    FILE *fp = fopen("contacts.txt", "w");
    if(fp == NULL)
    {
        printf(RED"ERROR: Failed to open file!\n"RESET);
        return Failure;
    }

    fprintf(fp, "%d\n", ab->contact_count);

    for(int i = 0; i < ab->contact_count; i++)
    {
        fprintf(fp, "%s,%s,%s\n",
                ab->contact_details[i].Name,
                ab->contact_details[i].Mobile_number,
                ab->contact_details[i].Mail_ID);
    }
    fclose(fp);
    printf(GREEN"SUCCESS: Contacts saved successfully to file\n"RESET);
    return Success;
}
// ===== LOAD CONTACTS FROM FILE =====
// Read contacts from "contact.txt" into the addressbook
Status load_contacts(AddressBook *ab)
{
    FILE *fp = fopen("contacts.txt", "r");

    // If file doesn't exist → start fresh
    if(fp == NULL)
    {
        ab->contact_count = 0;
        return Success;
    }
    int count;
    // Try reading number of contacts
    if(fscanf(fp, "%d\n", &count) != 1)
    {
        printf(YELLOW"WARNING: File empty or invalid. Starting fresh.\n"RESET);
        ab->contact_count = 0;
        fclose(fp);
        return Success;
    }
    // Limit check
    if(count < 0 || count > MAX)
    {
        printf(RED"ERROR: Invalid contact count in file!\n"RESET);
        ab->contact_count = 0;
        fclose(fp);
        return Failure;
    }

    ab->contact_count = 0;

    // Read contacts one by one
    for(int i = 0; i < count; i++)
    {
        char name[50], mobile[15], email[50];

        if(fscanf(fp, "%[^,],%[^,],%[^\n]\n", name, mobile, email) != 3)
        {
            printf(YELLOW"WARNING: Skipping invalid contact line %d\n", i + 1);
            continue;  // skip bad line
        }
        //Validate begore storing
        if (!validate_name(name) || !validate_mobile(mobile) || !validate_email(email))
        {
            printf(YELLOW"WARNING: Invalid data at line %d, skipping.\n", i + 1);
            continue;
        }
        // Store only valid contacts
        strcpy(ab->contact_details[ab->contact_count].Name, name);
        strcpy(ab->contact_details[ab->contact_count].Mobile_number, mobile);
        strcpy(ab->contact_details[ab->contact_count].Mail_ID, email);

        ab->contact_count++;
    }
    fclose(fp);
    printf(GREEN"SUCCESS: %d contacts loaded successfully.\n"RESET, ab->contact_count);
    return Success;
}