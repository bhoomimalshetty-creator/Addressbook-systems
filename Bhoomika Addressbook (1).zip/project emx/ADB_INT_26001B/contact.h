#ifndef CONTACT_H
#define CONTACT_H

#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define CYAN    "\033[36m"
#define WHITE   "\033[37m"

// Structures for the Fields
typedef struct Contact_data
{
    char Name[32];
    char Mobile_number[11];
    char Mail_ID[35];

} Contacts;

// Structures foe the Contact deatils
typedef struct AddressBook_Data
{
    // Array of structures for the Fields sturucture
    Contacts contact_details[100];
    // To keep the track no of contact count
    int contact_count;
} AddressBook;

typedef enum Status_info
{
    Failure,
    Success,
} Status;

/* Function declarations */

Status create_contact(AddressBook *);
void list_contacts(AddressBook *);
Status search_contacts(AddressBook *);
Status edit_contact(AddressBook *);
Status delete_contact(AddressBook *);
Status save_contacts(AddressBook *);
Status load_contacts(AddressBook *);

#endif
// CONTACT_H
// CONTACT_H 