/*Name:- Bhoomika
Name of the project:- Addressbook
Date:- 08-04-2026
Batch Name:- INT_26001B
Description:- The Address Book Project is a console-based application developed using the C programming language to store and manage contact details efficiently. The main purpose of this project is to allow users to create, search, update, 
delete, and display contact information in an organized manner. */


#include <stdio.h>
#include "contact.h"

#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define CYAN    "\033[36m"
#define WHITE   "\033[37m"
/* Structure declaration */

int main()
{
    /* Variable and structre defintion */
    int option;
    AddressBook addressbook;
    addressbook.contact_count = 0;
    load_contacts(&addressbook);

    while (1)
    {
        printf(CYAN"\nAddress book menu\n"RESET); /* Give a prompt message for a user */
        printf(WHITE"1.Add contact\n2.search contact\n3.Edit contact\n4.Delete contact\n5.Display contact\n6.Save contact\n7.Exit\n"RESET);
        printf(BLUE"Enter the option : "RESET);
        scanf("%d", &option);
        getchar();
        switch (option) /* Based on choosed option */
        {
        case 1:
        {
            create_contact(&addressbook);
            break;
        }

        case 2:
        {
            printf("Search Contact menu : \n1.Name \n2.Mobile number \n2.Mail ID \n4.Exit \nEnter the option : ");
            search_contacts(&addressbook);
            break;
        }

        case 3:
            printf("Edit Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */

            edit_contact(&addressbook);
            break;

        case 4:
        {
            printf("Delete Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */

            delete_contact(&addressbook);
            break;
        }
        case 5:
        {
            printf("List Contacts:");
            list_contacts(&addressbook);
            break;
        }

        case 6:
            printf("Saving contacts\n");
            save_contacts(&addressbook);
            break;

        case 7:
            printf("INFO : Save and Exit...\n");
            return 0;

        default:
            printf("Invalid option \n");
            break;
        }
    }
    return 0;
}